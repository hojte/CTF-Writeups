qemu-system-i386 -fda game.bin
